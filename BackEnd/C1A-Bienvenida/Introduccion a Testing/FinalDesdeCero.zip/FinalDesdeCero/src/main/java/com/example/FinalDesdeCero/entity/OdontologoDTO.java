package com.example.FinalDesdeCero.entity;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OdontologoDTO {
    private Long id;
    private String apellido;
    private String nombre;
    private String matricula;
}
